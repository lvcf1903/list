//var jiajson1 = "[{\"id\":\"12939\",\"i_cataid\":\"48831\",\"date\":\"\",\"name\":\"在文物保护单位及其保护范围、建设控制地带违规施工的处罚\",\"auditor\":\"2014-11-06 18:06:37\",\"times\":\"0\",\"dotimes\":\"0\",\"commenttimes\":\"0\",\"score\":\"0\",\"grzt\":\"19,\",\"grdx\":\"\",\"frzt\":\"11,\",\"frdx\":\"\",\"allname\":\"\",\"dcode\":\"b290390f-c153-4c30-9174-0063f7aaa4f0\",\"type\":\"03\",\"maincode\":\"00001\",\"childcode\":\"000\",\"domain\":\"\",\"state\":\"\",\"usertype\":\"个人,法人,其他组织\",\"doplace\":\"\",\"spconditions\":\"\",\"filename\":\"http://www.zjzwfw.gov.cn/art/2014/11/6/art_48831_12939.html\",\"questions\":null,\"askphone\":\"\",\"complaintphone\":\"\",\"isfree\":\"\",\"sfconditions\":\"\",\"innersteps\":\"\",\"outersteps\":\"\",\"files\":\"0\",\"mostdays\":\"1\",\"promisedays\":\"\",\"localid\":\"330000\",\"deptid\":\"002482349\",\"deptname\":\"\",\"deptallname\":\"浙江省文物局\",\"groupname\":\"1\",\"systype\":\"0\",\"sysapp\":\"\",\"sysurl1\":\"\",\"sysurl2\":\"\",\"qlfrom\":\"法定本级行使\",\"iscollect\":false,\"place\":\"0\",\"fdconditions\":\"0\",\"publish\":\"1\",\"starlevel\":\"\",\"secret\":\"0\",\"isHaveChildren\":\"0\",\"orgcode\":\"001003081\",\"docode\":null},{\"id\":\"12939\",\"i_cataid\":\"48831\",\"date\":\"\",\"name\":\"对文物和博物馆保护工作中有显著成绩的单位和个人予以表彰奖励\",\"auditor\":\"2014-11-06 18:06:37\",\"times\":\"0\",\"dotimes\":\"0\",\"commenttimes\":\"0\",\"score\":\"0\",\"grzt\":\"19,\",\"grdx\":\"\",\"frzt\":\"11,\",\"frdx\":\"\",\"allname\":\"\",\"dcode\":\"b290390f-c153-4c30-9174-0063f7aaa4f0\",\"type\":\"03\",\"maincode\":\"00001\",\"childcode\":\"000\",\"domain\":\"\",\"state\":\"\",\"usertype\":\"个人,法人,其他组织\",\"doplace\":\"\",\"spconditions\":\"\",\"filename\":\"http://www.zjzwfw.gov.cn/art/2014/11/6/art_48831_12939.html\",\"questions\":null,\"askphone\":\"\",\"complaintphone\":\"\",\"isfree\":\"\",\"sfconditions\":\"\",\"innersteps\":\"\",\"outersteps\":\"\",\"files\":\"0\",\"mostdays\":\"1\",\"promisedays\":\"\",\"localid\":\"330000\",\"deptid\":\"002482349\",\"deptname\":\"\",\"deptallname\":\"浙江省文物局\",\"groupname\":\"1\",\"systype\":\"0\",\"sysapp\":\"\",\"sysurl1\":\"\",\"sysurl2\":\"\",\"qlfrom\":\"法定本级行使\",\"iscollect\":false,\"place\":\"0\",\"fdconditions\":\"0\",\"publish\":\"1\",\"starlevel\":\"\",\"secret\":\"0\",\"isHaveChildren\":\"0\",\"orgcode\":\"001003081\",\"docode\":null},{\"id\":\"12939\",\"i_cataid\":\"48831\",\"date\":\"\",\"name\":\"在地下文物埋藏区内擅自进行工程建设，或者阻挠考古发掘单位进行考古工作的处罚\",\"auditor\":\"2014-11-06 18:06:37\",\"times\":\"0\",\"dotimes\":\"0\",\"commenttimes\":\"0\",\"score\":\"0\",\"grzt\":\"19,\",\"grdx\":\"\",\"frzt\":\"11,\",\"frdx\":\"\",\"allname\":\"\",\"dcode\":\"b290390f-c153-4c30-9174-0063f7aaa4f0\",\"type\":\"03\",\"maincode\":\"00001\",\"childcode\":\"000\",\"domain\":\"\",\"state\":\"\",\"usertype\":\"个人,法人,其他组织\",\"doplace\":\"\",\"spconditions\":\"\",\"filename\":\"http://www.zjzwfw.gov.cn/art/2014/11/6/art_48831_12939.html\",\"questions\":null,\"askphone\":\"\",\"complaintphone\":\"\",\"isfree\":\"\",\"sfconditions\":\"\",\"innersteps\":\"\",\"outersteps\":\"\",\"files\":\"0\",\"mostdays\":\"1\",\"promisedays\":\"\",\"localid\":\"330000\",\"deptid\":\"002482349\",\"deptname\":\"\",\"deptallname\":\"浙江省文物局\",\"groupname\":\"1\",\"systype\":\"0\",\"sysapp\":\"\",\"sysurl1\":\"\",\"sysurl2\":\"\",\"qlfrom\":\"法定本级行使\",\"iscollect\":false,\"place\":\"0\",\"fdconditions\":\"0\",\"publish\":\"1\",\"starlevel\":\"\",\"secret\":\"0\",\"isHaveChildren\":\"0\",\"orgcode\":\"001003081\",\"docode\":null},{\"id\":\"12939\",\"i_cataid\":\"48831\",\"date\":\"\",\"name\":\"基本养老保险参保单位职工提前退休（退职）确认\",\"auditor\":\"2014-11-06 18:06:37\",\"times\":\"0\",\"dotimes\":\"0\",\"commenttimes\":\"0\",\"score\":\"0\",\"grzt\":\"19,\",\"grdx\":\"\",\"frzt\":\"11,\",\"frdx\":\"\",\"allname\":\"\",\"dcode\":\"b290390f-c153-4c30-9174-0063f7aaa4f0\",\"type\":\"03\",\"maincode\":\"00001\",\"childcode\":\"000\",\"domain\":\"\",\"state\":\"\",\"usertype\":\"个人,法人,其他组织\",\"doplace\":\"\",\"spconditions\":\"\",\"filename\":\"http://www.zjzwfw.gov.cn/art/2014/11/6/art_48831_12939.html\",\"questions\":null,\"askphone\":\"\",\"complaintphone\":\"\",\"isfree\":\"\",\"sfconditions\":\"\",\"innersteps\":\"\",\"outersteps\":\"\",\"files\":\"0\",\"mostdays\":\"1\",\"promisedays\":\"\",\"localid\":\"330000\",\"deptid\":\"002482349\",\"deptname\":\"\",\"deptallname\":\"浙江省文物局\",\"groupname\":\"1\",\"systype\":\"0\",\"sysapp\":\"\",\"sysurl1\":\"\",\"sysurl2\":\"\",\"qlfrom\":\"法定本级行使\",\"iscollect\":false,\"place\":\"0\",\"fdconditions\":\"0\",\"publish\":\"1\",\"starlevel\":\"\",\"secret\":\"0\",\"isHaveChildren\":\"0\",\"orgcode\":\"001003081\",\"docode\":null},{\"id\":\"12939\",\"i_cataid\":\"48831\",\"date\":\"\",\"name\":\"中华人民共和国护照\",\"auditor\":\"2014-11-06 18:06:37\",\"times\":\"0\",\"dotimes\":\"0\",\"commenttimes\":\"0\",\"score\":\"0\",\"grzt\":\"19,\",\"grdx\":\"\",\"frzt\":\"11,\",\"frdx\":\"\",\"allname\":\"\",\"dcode\":\"b290390f-c153-4c30-9174-0063f7aaa4f0\",\"type\":\"03\",\"maincode\":\"00001\",\"childcode\":\"000\",\"domain\":\"\",\"state\":\"\",\"usertype\":\"个人,法人,其他组织\",\"doplace\":\"\",\"spconditions\":\"\",\"filename\":\"http://www.zjzwfw.gov.cn/art/2014/11/6/art_48831_12939.html\",\"questions\":null,\"askphone\":\"\",\"complaintphone\":\"\",\"isfree\":\"\",\"sfconditions\":\"\",\"innersteps\":\"\",\"outersteps\":\"\",\"files\":\"0\",\"mostdays\":\"1\",\"promisedays\":\"\",\"localid\":\"330000\",\"deptid\":\"002482349\",\"deptname\":\"\",\"deptallname\":\"浙江省文物局\",\"groupname\":\"1\",\"systype\":\"0\",\"sysapp\":\"\",\"sysurl1\":\"\",\"sysurl2\":\"\",\"qlfrom\":\"法定本级行使\",\"iscollect\":false,\"place\":\"0\",\"fdconditions\":\"0\",\"publish\":\"1\",\"starlevel\":\"\",\"secret\":\"0\",\"isHaveChildren\":\"0\",\"orgcode\":\"001003081\",\"docode\":null}]";
var jiajson2 = "[{\"auditor\":\"\",\"spconditions\":\"\",\"maincode\":\"\",\"score\":\"\",\"type\":\"\",\"dotimes\":\"\",\"frzt\":\"\",\"orgcode\":\"\",\"systype\":\"\",\"deptid\":\"\",\"dcode\":\"\",\"grzt\":\"\",\"deptallname\":\"\",\"cntime\":\"2\",\"place\":\"\",\"askphone\":\"\",\"deptname\":\"\",\"frdx\":\"\",\"localid\":\"\",\"promisedays\":\"\",\"complaintphone\":\"\",\"isfree\":\"\",\"commenttimes\":\"\",\"questions\":\"\",\"mostdays\":\"\",\"fdconditions\":\"\",\"i_cataid\":\"\",\"isHaveChildren\":\"\",\"grdx\":\"\",\"qlfrom\":\"\",\"sysurl1\":\"\",\"state\":\"\",\"childcode\":\"\",\"groupname\":\"市行政执法局\",\"date\":\"\",\"id\":\"62ebe790-03ae-49fe-824e-df484b7d1b98\",\"times\":\"\",\"lxmobile\":\"0579-85570036\",\"name\":\"临时占用或者挖掘城市道路审批\",\"domain\":\"\",\"doplace\":\"\",\"sysurl2\":\"\",\"fdtime\":\"20\",\"publish\":\"\",\"sfconditions\":\"\",\"innersteps\":\"\",\"outersteps\":\"\",\"allname\":\"\",\"files\":\"\",\"docode\":\"\",\"jdmobile\":\"0579-85572028\",\"usertype\":\"\",\"starlevel\":\"\",\"iscollect\":\"\",\"sysapp\":\"\",\"secret\":\"\",\"filename\":\"\"},{\"auditor\":\"\",\"spconditions\":\"\",\"maincode\":\"\",\"score\":\"\",\"type\":\"\",\"dotimes\":\"\",\"frzt\":\"\",\"orgcode\":\"\",\"systype\":\"\",\"deptid\":\"\",\"dcode\":\"\",\"grzt\":\"\",\"deptallname\":\"\",\"cntime\":\"20\",\"place\":\"\",\"askphone\":\"\",\"deptname\":\"\",\"frdx\":\"\",\"localid\":\"\",\"promisedays\":\"\",\"complaintphone\":\"\",\"isfree\":\"\",\"commenttimes\":\"\",\"questions\":\"\",\"mostdays\":\"\",\"fdconditions\":\"\",\"i_cataid\":\"\",\"isHaveChildren\":\"\",\"grdx\":\"\",\"qlfrom\":\"\",\"sysurl1\":\"\",\"state\":\"\",\"childcode\":\"\",\"groupname\":\"市建设局（市散装水泥办公室）\",\"date\":\"\",\"id\":\"93713e6a-6ff7-43ff-add3-6bf2b60b5666\",\"times\":\"\",\"lxmobile\":\"0579-85232755、0579-85232756、0579-85232757\",\"name\":\"勘察设计工程师执业资格（一级注册结构工程师和其他专业注册工程师）注册初审（更改、补办证章）\",\"domain\":\"\",\"doplace\":\"\",\"sysurl2\":\"\",\"fdtime\":\"20\",\"publish\":\"\",\"sfconditions\":\"\",\"innersteps\":\"\",\"outersteps\":\"\",\"allname\":\"\",\"files\":\"\",\"docode\":\"\",\"jdmobile\":\"0579-85580038\",\"usertype\":\"\",\"starlevel\":\"\",\"iscollect\":\"\",\"sysapp\":\"\",\"secret\":\"\",\"filename\":\"\"},{\"auditor\":\"\",\"spconditions\":\"\",\"maincode\":\"\",\"score\":\"\",\"type\":\"\",\"dotimes\":\"\",\"frzt\":\"\",\"orgcode\":\"\",\"systype\":\"\",\"deptid\":\"\",\"dcode\":\"\",\"grzt\":\"\",\"deptallname\":\"\",\"cntime\":\"20\",\"place\":\"\",\"askphone\":\"\",\"deptname\":\"\",\"frdx\":\"\",\"localid\":\"\",\"promisedays\":\"\",\"complaintphone\":\"\",\"isfree\":\"\",\"commenttimes\":\"\",\"questions\":\"\",\"mostdays\":\"\",\"fdconditions\":\"\",\"i_cataid\":\"\",\"isHaveChildren\":\"\",\"grdx\":\"\",\"qlfrom\":\"\",\"sysurl1\":\"\",\"state\":\"\",\"childcode\":\"\",\"groupname\":\"市建设局（市散装水泥办公室）\",\"date\":\"\",\"id\":\"95692b13-4088-49e9-8423-cf52232f240f\",\"times\":\"\",\"lxmobile\":\"0579-85232755、0579-85232756、0579-85232757\",\"name\":\"勘察设计工程师执业资格注册（更改、补办证章）\",\"domain\":\"\",\"doplace\":\"\",\"sysurl2\":\"\",\"fdtime\":\"20\",\"publish\":\"\",\"sfconditions\":\"\",\"innersteps\":\"\",\"outersteps\":\"\",\"allname\":\"\",\"files\":\"\",\"docode\":\"\",\"jdmobile\":\"0579-85580038\",\"usertype\":\"\",\"starlevel\":\"\",\"iscollect\":\"\",\"sysapp\":\"\",\"secret\":\"\",\"filename\":\"\"},{\"auditor\":\"\",\"spconditions\":\"\",\"maincode\":\"\",\"score\":\"\",\"type\":\"\",\"dotimes\":\"\",\"frzt\":\"\",\"orgcode\":\"\",\"systype\":\"\",\"deptid\":\"\",\"dcode\":\"\",\"grzt\":\"\",\"deptallname\":\"\",\"cntime\":\"20\",\"place\":\"\",\"askphone\":\"\",\"deptname\":\"\",\"frdx\":\"\",\"localid\":\"\",\"promisedays\":\"\",\"complaintphone\":\"\",\"isfree\":\"\",\"commenttimes\":\"\",\"questions\":\"\",\"mostdays\":\"\",\"fdconditions\":\"\",\"i_cataid\":\"\",\"isHaveChildren\":\"\",\"grdx\":\"\",\"qlfrom\":\"\",\"sysurl1\":\"\",\"state\":\"\",\"childcode\":\"\",\"groupname\":\"市建设局（市散装水泥办公室）\",\"date\":\"\",\"id\":\"256c1862-d7ca-4d22-866f-b39f8d283fc0\",\"times\":\"\",\"lxmobile\":\"0579-85232755、0579-85232756、0579-85232757\",\"name\":\"建筑师执业资格注册（更改、补办证章）\",\"domain\":\"\",\"doplace\":\"\",\"sysurl2\":\"\",\"fdtime\":\"20\",\"publish\":\"\",\"sfconditions\":\"\",\"innersteps\":\"\",\"outersteps\":\"\",\"allname\":\"\",\"files\":\"\",\"docode\":\"\",\"jdmobile\":\"0579-85580038\",\"usertype\":\"\",\"starlevel\":\"\",\"iscollect\":\"\",\"sysapp\":\"\",\"secret\":\"\",\"filename\":\"\"}]";
//var jiajson3 = "[{\"id\":\"12939\",\"i_cataid\":\"48831\",\"date\":\"\",\"name\":\"博士后进出站审核\",\"auditor\":\"2014-11-06 18:06:37\",\"times\":\"0\",\"dotimes\":\"0\",\"commenttimes\":\"0\",\"score\":\"0\",\"grzt\":\"19,\",\"grdx\":\"\",\"frzt\":\"11,\",\"frdx\":\"\",\"allname\":\"\",\"dcode\":\"b290390f-c153-4c30-9174-0063f7aaa4f0\",\"type\":\"03\",\"maincode\":\"00001\",\"childcode\":\"000\",\"domain\":\"\",\"state\":\"\",\"usertype\":\"个人,法人,其他组织\",\"doplace\":\"\",\"spconditions\":\"\",\"filename\":\"http://www.zjzwfw.gov.cn/art/2014/11/6/art_48831_12939.html\",\"questions\":null,\"askphone\":\"\",\"complaintphone\":\"\",\"isfree\":\"\",\"sfconditions\":\"\",\"innersteps\":\"\",\"outersteps\":\"\",\"files\":\"0\",\"mostdays\":\"1\",\"promisedays\":\"\",\"localid\":\"330000\",\"deptid\":\"002482349\",\"deptname\":\"\",\"deptallname\":\"浙江省文物局\",\"groupname\":\"1\",\"systype\":\"0\",\"sysapp\":\"\",\"sysurl1\":\"\",\"sysurl2\":\"\",\"qlfrom\":\"法定本级行使\",\"iscollect\":false,\"place\":\"0\",\"fdconditions\":\"0\",\"publish\":\"1\",\"starlevel\":\"\",\"secret\":\"0\",\"isHaveChildren\":\"0\",\"orgcode\":\"001003081\",\"docode\":null},{\"id\":\"12939\",\"i_cataid\":\"48831\",\"date\":\"\",\"name\":\"奖励在测绘科学技术进步中作出贡献的单位和个人\",\"auditor\":\"2014-11-06 18:06:37\",\"times\":\"0\",\"dotimes\":\"0\",\"commenttimes\":\"0\",\"score\":\"0\",\"grzt\":\"19,\",\"grdx\":\"\",\"frzt\":\"11,\",\"frdx\":\"\",\"allname\":\"\",\"dcode\":\"b290390f-c153-4c30-9174-0063f7aaa4f0\",\"type\":\"03\",\"maincode\":\"00001\",\"childcode\":\"000\",\"domain\":\"\",\"state\":\"\",\"usertype\":\"个人,法人,其他组织\",\"doplace\":\"\",\"spconditions\":\"\",\"filename\":\"http://www.zjzwfw.gov.cn/art/2014/11/6/art_48831_12939.html\",\"questions\":null,\"askphone\":\"\",\"complaintphone\":\"\",\"isfree\":\"\",\"sfconditions\":\"\",\"innersteps\":\"\",\"outersteps\":\"\",\"files\":\"0\",\"mostdays\":\"1\",\"promisedays\":\"\",\"localid\":\"330000\",\"deptid\":\"002482349\",\"deptname\":\"\",\"deptallname\":\"浙江省文物局\",\"groupname\":\"1\",\"systype\":\"0\",\"sysapp\":\"\",\"sysurl1\":\"\",\"sysurl2\":\"\",\"qlfrom\":\"法定本级行使\",\"iscollect\":false,\"place\":\"0\",\"fdconditions\":\"0\",\"publish\":\"1\",\"starlevel\":\"\",\"secret\":\"0\",\"isHaveChildren\":\"0\",\"orgcode\":\"001003081\",\"docode\":null},{\"id\":\"12939\",\"i_cataid\":\"48831\",\"date\":\"\",\"name\":\"在地下文物埋藏区内擅自进行工程建设，或者阻挠考古发掘单位进行考古工作的处罚\",\"auditor\":\"2014-11-06 18:06:37\",\"times\":\"0\",\"dotimes\":\"0\",\"commenttimes\":\"0\",\"score\":\"0\",\"grzt\":\"19,\",\"grdx\":\"\",\"frzt\":\"11,\",\"frdx\":\"\",\"allname\":\"\",\"dcode\":\"b290390f-c153-4c30-9174-0063f7aaa4f0\",\"type\":\"03\",\"maincode\":\"00001\",\"childcode\":\"000\",\"domain\":\"\",\"state\":\"\",\"usertype\":\"个人,法人,其他组织\",\"doplace\":\"\",\"spconditions\":\"\",\"filename\":\"http://www.zjzwfw.gov.cn/art/2014/11/6/art_48831_12939.html\",\"questions\":null,\"askphone\":\"\",\"complaintphone\":\"\",\"isfree\":\"\",\"sfconditions\":\"\",\"innersteps\":\"\",\"outersteps\":\"\",\"files\":\"0\",\"mostdays\":\"1\",\"promisedays\":\"\",\"localid\":\"330000\",\"deptid\":\"002482349\",\"deptname\":\"\",\"deptallname\":\"浙江省文物局\",\"groupname\":\"1\",\"systype\":\"0\",\"sysapp\":\"\",\"sysurl1\":\"\",\"sysurl2\":\"\",\"qlfrom\":\"法定本级行使\",\"iscollect\":false,\"place\":\"0\",\"fdconditions\":\"0\",\"publish\":\"1\",\"starlevel\":\"\",\"secret\":\"0\",\"isHaveChildren\":\"0\",\"orgcode\":\"001003081\",\"docode\":null},{\"id\":\"12939\",\"i_cataid\":\"48831\",\"date\":\"\",\"name\":\"基本养老保险参保单位职工提前退休（退职）确认\",\"auditor\":\"2014-11-06 18:06:37\",\"times\":\"0\",\"dotimes\":\"0\",\"commenttimes\":\"0\",\"score\":\"0\",\"grzt\":\"19,\",\"grdx\":\"\",\"frzt\":\"11,\",\"frdx\":\"\",\"allname\":\"\",\"dcode\":\"b290390f-c153-4c30-9174-0063f7aaa4f0\",\"type\":\"03\",\"maincode\":\"00001\",\"childcode\":\"000\",\"domain\":\"\",\"state\":\"\",\"usertype\":\"个人,法人,其他组织\",\"doplace\":\"\",\"spconditions\":\"\",\"filename\":\"http://www.zjzwfw.gov.cn/art/2014/11/6/art_48831_12939.html\",\"questions\":null,\"askphone\":\"\",\"complaintphone\":\"\",\"isfree\":\"\",\"sfconditions\":\"\",\"innersteps\":\"\",\"outersteps\":\"\",\"files\":\"0\",\"mostdays\":\"1\",\"promisedays\":\"\",\"localid\":\"330000\",\"deptid\":\"002482349\",\"deptname\":\"\",\"deptallname\":\"浙江省文物局\",\"groupname\":\"1\",\"systype\":\"0\",\"sysapp\":\"\",\"sysurl1\":\"\",\"sysurl2\":\"\",\"qlfrom\":\"法定本级行使\",\"iscollect\":false,\"place\":\"0\",\"fdconditions\":\"0\",\"publish\":\"1\",\"starlevel\":\"\",\"secret\":\"0\",\"isHaveChildren\":\"0\",\"orgcode\":\"001003081\",\"docode\":null},{\"id\":\"12939\",\"i_cataid\":\"48831\",\"date\":\"\",\"name\":\"中华人民共和国护照\",\"auditor\":\"2014-11-06 18:06:37\",\"times\":\"0\",\"dotimes\":\"0\",\"commenttimes\":\"0\",\"score\":\"0\",\"grzt\":\"19,\",\"grdx\":\"\",\"frzt\":\"11,\",\"frdx\":\"\",\"allname\":\"\",\"dcode\":\"b290390f-c153-4c30-9174-0063f7aaa4f0\",\"type\":\"03\",\"maincode\":\"00001\",\"childcode\":\"000\",\"domain\":\"\",\"state\":\"\",\"usertype\":\"个人,法人,其他组织\",\"doplace\":\"\",\"spconditions\":\"\",\"filename\":\"http://www.zjzwfw.gov.cn/art/2014/11/6/art_48831_12939.html\",\"questions\":null,\"askphone\":\"\",\"complaintphone\":\"\",\"isfree\":\"\",\"sfconditions\":\"\",\"innersteps\":\"\",\"outersteps\":\"\",\"files\":\"0\",\"mostdays\":\"1\",\"promisedays\":\"\",\"localid\":\"330000\",\"deptid\":\"002482349\",\"deptname\":\"\",\"deptallname\":\"浙江省文物局\",\"groupname\":\"1\",\"systype\":\"0\",\"sysapp\":\"\",\"sysurl1\":\"\",\"sysurl2\":\"\",\"qlfrom\":\"法定本级行使\",\"iscollect\":false,\"place\":\"0\",\"fdconditions\":\"0\",\"publish\":\"1\",\"starlevel\":\"\",\"secret\":\"0\",\"isHaveChildren\":\"0\",\"orgcode\":\"001003081\",\"docode\":null},{\"id\":\"12939\",\"i_cataid\":\"48831\",\"date\":\"\",\"name\":\"食品药品投诉举报奖励\",\"auditor\":\"2014-11-06 18:06:37\",\"times\":\"0\",\"dotimes\":\"0\",\"commenttimes\":\"0\",\"score\":\"0\",\"grzt\":\"19,\",\"grdx\":\"\",\"frzt\":\"11,\",\"frdx\":\"\",\"allname\":\"\",\"dcode\":\"b290390f-c153-4c30-9174-0063f7aaa4f0\",\"type\":\"03\",\"maincode\":\"00001\",\"childcode\":\"000\",\"domain\":\"\",\"state\":\"\",\"usertype\":\"个人,法人,其他组织\",\"doplace\":\"\",\"spconditions\":\"\",\"filename\":\"http://www.zjzwfw.gov.cn/art/2014/11/6/art_48831_12939.html\",\"questions\":null,\"askphone\":\"\",\"complaintphone\":\"\",\"isfree\":\"\",\"sfconditions\":\"\",\"innersteps\":\"\",\"outersteps\":\"\",\"files\":\"0\",\"mostdays\":\"1\",\"promisedays\":\"\",\"localid\":\"330000\",\"deptid\":\"002482349\",\"deptname\":\"\",\"deptallname\":\"浙江省文物局\",\"groupname\":\"1\",\"systype\":\"0\",\"sysapp\":\"\",\"sysurl1\":\"\",\"sysurl2\":\"\",\"qlfrom\":\"法定本级行使\",\"iscollect\":false,\"place\":\"0\",\"fdconditions\":\"0\",\"publish\":\"1\",\"starlevel\":\"\",\"secret\":\"0\",\"isHaveChildren\":\"0\",\"orgcode\":\"001003081\",\"docode\":null},{\"id\":\"12939\",\"i_cataid\":\"48831\",\"date\":\"\",\"name\":\"擅自变更文物保护工程设计方案的重要内容进行施工的处罚\",\"auditor\":\"2014-11-06 18:06:37\",\"times\":\"0\",\"dotimes\":\"0\",\"commenttimes\":\"0\",\"score\":\"0\",\"grzt\":\"19,\",\"grdx\":\"\",\"frzt\":\"11,\",\"frdx\":\"\",\"allname\":\"\",\"dcode\":\"b290390f-c153-4c30-9174-0063f7aaa4f0\",\"type\":\"03\",\"maincode\":\"00001\",\"childcode\":\"000\",\"domain\":\"\",\"state\":\"\",\"usertype\":\"个人,法人,其他组织\",\"doplace\":\"\",\"spconditions\":\"\",\"filename\":\"http://www.zjzwfw.gov.cn/art/2014/11/6/art_48831_12939.html\",\"questions\":null,\"askphone\":\"\",\"complaintphone\":\"\",\"isfree\":\"\",\"sfconditions\":\"\",\"innersteps\":\"\",\"outersteps\":\"\",\"files\":\"0\",\"mostdays\":\"1\",\"promisedays\":\"\",\"localid\":\"330000\",\"deptid\":\"002482349\",\"deptname\":\"\",\"deptallname\":\"浙江省文物局\",\"groupname\":\"1\",\"systype\":\"0\",\"sysapp\":\"\",\"sysurl1\":\"\",\"sysurl2\":\"\",\"qlfrom\":\"法定本级行使\",\"iscollect\":false,\"place\":\"0\",\"fdconditions\":\"0\",\"publish\":\"1\",\"starlevel\":\"\",\"secret\":\"0\",\"isHaveChildren\":\"0\",\"orgcode\":\"001003081\",\"docode\":null},{\"id\":\"12939\",\"i_cataid\":\"48831\",\"date\":\"\",\"name\":\"在地下文物埋藏区内擅自进行工程建设，或者阻挠考古发掘单位进行考古工作的处罚\",\"auditor\":\"2014-11-06 18:06:37\",\"times\":\"0\",\"dotimes\":\"0\",\"commenttimes\":\"0\",\"score\":\"0\",\"grzt\":\"19,\",\"grdx\":\"\",\"frzt\":\"11,\",\"frdx\":\"\",\"allname\":\"\",\"dcode\":\"b290390f-c153-4c30-9174-0063f7aaa4f0\",\"type\":\"03\",\"maincode\":\"00001\",\"childcode\":\"000\",\"domain\":\"\",\"state\":\"\",\"usertype\":\"个人,法人,其他组织\",\"doplace\":\"\",\"spconditions\":\"\",\"filename\":\"http://www.zjzwfw.gov.cn/art/2014/11/6/art_48831_12939.html\",\"questions\":null,\"askphone\":\"\",\"complaintphone\":\"\",\"isfree\":\"\",\"sfconditions\":\"\",\"innersteps\":\"\",\"outersteps\":\"\",\"files\":\"0\",\"mostdays\":\"1\",\"promisedays\":\"\",\"localid\":\"330000\",\"deptid\":\"002482349\",\"deptname\":\"\",\"deptallname\":\"浙江省文物局\",\"groupname\":\"1\",\"systype\":\"0\",\"sysapp\":\"\",\"sysurl1\":\"\",\"sysurl2\":\"\",\"qlfrom\":\"法定本级行使\",\"iscollect\":false,\"place\":\"0\",\"fdconditions\":\"0\",\"publish\":\"1\",\"starlevel\":\"\",\"secret\":\"0\",\"isHaveChildren\":\"0\",\"orgcode\":\"001003081\",\"docode\":null}]";
var example1 = new Vue({
	el: '#parent',
	data: {
		matters: []
	}
})
var dataArray;
var pagenum = 1;
var foruser;

/*
 * 新增 foruser 字段  1.企业 2.个人 3.个人和企业
 * 
 */

//请求网上预约列表
function requestOrderList(requesttype, colid, keyword) {
	if(requesttype == 0 || requesttype == 1) {
		pagenum = 1;
	} else {
		pagenum++;
	}
	var date;
	var requesturl;
	//判断是网上预约 还是网上办证（证明）
	if(onlinetype == "01") { //01网上预约
		date = {
			siteid: vsiteid,
			pagenum: pagenum,
//			usertype: usertype,
			colid: colid, //所属的分类id
			pagesize: "15", //此字段写死成15不能改，因为后台每页固定放15条数据，pagesize是几就取当前页的前几条数据
			keyword: keyword
		}
		requesturl = overallInterface + "ywzw/interface/getOrderInfoList.do";
	} else if(onlinetype == "02") { //02 网上办证
		date = {
			pagenum: pagenum,
			pagesize: "15", //15的原因同上
//			usertype: usertype,
			colid: colid, //所属的分类id
			siteid: vsiteid,
			keyword: keyword
		}
		requesturl = overallInterface + "ywzw/interface/getOnlineHandleInfoList.do";
	}
	document.getElementById('loading').style.display = 'block';
	//菊花
	var opts = {
		//参数列表    
		lines: 10, // loading小块的数量
		length: 10, // 小块的长度
		width: 4, // 小块的宽度
		radius: 8, // 整个圆形的半径
		corners: 1, // 小块的圆角，越大则越圆
		rotate: 0, // loading动画的旋转度数，貌似没什么实际作用
		color: '#ddd', // 颜色
		speed: 1, // 变换速度
		trail: 60, // 余晖的百分比
		shadow: false, // 是否渲染出阴影
		hwaccel: false, // 是否启用硬件加速
		className: 'spinner', // 给loading添加的css样式名
		zIndex: 2e9, // The z-index (defaults to 2000000000)
		top: 'auto', // Top position relative to parent in px
		left: 'auto' // Left position relative to parent in px
	};
	var target = document.getElementById('food');
	var spinner = new Spinner(opts).spin(target);

	myRequest({
		async: true,
		url: requesturl,
		data: date,
		header: '',
		success: function(data) { //成功
			document.getElementById('loading').style.display = 'none';
			var obj = data;
			if(requesttype == 0 || requesttype == 1) { //刷新
				if(requesttype == 1) {
					mui('#pullrefresh').pullRefresh().endPulldownToRefresh(); //refresh completed
				}
				if(obj.length > 0) { //有数据

					dataArray = [];
					dataArray = obj;
				} else { //无数据
					dataArray = [];
					//					mui.alert("暂无数据");
				}
				pagenum = 1;
			} else { //加载更多
				if(obj.length > 0) { //有数据

					dataArray = dataArray.concat(obj);
				} else {

				}
				mui('#pullrefresh').pullRefresh().endPullupToRefresh(obj.length == 0); //参数为true代表没有更多数据了。
			}

			if(dataArray.length > 0) { //有数据
				example1.matters = [];
				for(var i = 0; i < dataArray.length; i++) {
					if(onlinetype == "01") { //01网上预约
						example1.matters.push({
							index: i,
							name: dataArray[i].name,
							vid: dataArray[i].id,
							itemcode: dataArray[i].addType,
							webid: dataArray[i].webid,
							addType: dataArray[i].addType,
							department: dataArray[i].groupname,
							foruser: dataArray[i].foruser
						});
					} else {
						//判断个人法人
						var userType;
						foruser = dataArray[i].foruser;
						if(foruser == "2") {
							userType = "法人用户";
						} else if(foruser == "1") {
							userType = "个人用户";
						} else if(foruser == "3") {
							userType = "民间组织";
						} else if(foruser == "4") {
							userType = "个人用户，法人用户";
						} else if(foruser == "6") {
							userType = "法人用户，民间组织";
						} else if(foruser == "5") {
							userType = "个人用户，民间组织";
						} else if(foruser == "7") {
							userType = "个人用户，法人用户，民间组织";
						} else {
							userType = "暂无";
						}
						var lxdh = dataArray[i].lxmobile.split("、")[0]; //取第一个电话
						var jddh = dataArray[i].jdmobile.split("、")[0]; //取第一个电话
						var vcntime = dataArray[i].cntime;
						if((new RegExp("\\S+")).test(vcntime) && vcntime != null && vcntime != -1) { //判断字符串是否为空或都是空格
							vcntime += '天';
						} else {
							vcntime = '无期限';
						}

						example1.matters.push({
							index: i,
							name: dataArray[i].name,
							vid: dataArray[i].id,
							department: dataArray[i].groupname,
							cntime: vcntime,
							lxmobile: lxdh,
							jdmobile: jddh,
							sfspyz: dataArray[i].sfspyz,
							bdcl: dataArray[i].bdcl,
							itemcode: dataArray[i].itemcode,
							webid: dataArray[i].webid,
							addType: dataArray[i].addType,
							sfly: dataArray[i].sfly,
							appurl: dataArray[i].appurl,
							userType: userType,
							foruser: dataArray[i].foruser,
							basecode: dataArray[i].basecode,
							areacode: dataArray[i].areacode
						});
					}

					if(i == 0) {
						document.getElementById("parent").style.display = "block";
						document.getElementById("badmessage").style.display = "none";
						document.getElementById("pullrefresh").style.display = "block";
						document.getElementById("listcontent").style.display = "block";
					}
				}
				setTimeout(hideDetailTable, 5);
			} else { //无数据
				document.getElementById("badmessage").style.display = "block";
				document.getElementById("parent").style.display = "none";
			}
		},
		fail: function(data) { //失败
			document.getElementById('loading').style.display = 'none';
			if(requesttype == 0) { //刷新
				mui('#pullrefresh').pullRefresh().endPulldownToRefresh(); //refresh completed

			} else { //加载更多
				mui('#pullrefresh').pullRefresh().endPullupToRefresh(); //参数为true代表没有更多数据了。
			}
			mui.alert("加载失败");
			document.getElementById("badmessage").style.display = "block";
			document.getElementById("parent").style.display = "none";

		}
	});
}

function hideDetailTable() {
	//判断容器类型，浏览器还是APP
//	var userInfo;
//	if(container == "web") {
//		//				requestToken();
//		userInfo = storage.wxuserInfo;
//		if(userInfo) {
//			userInfo = JSON.parse(userInfo);
//		}
//
//	} else { //app 使用jssdk获取用户信息
//		userInfo = storage.userInfo;
//		if(userInfo) {
//			userInfo = JSON.parse(userInfo);
//		}
//
//	}
	//onlinetype:01 网上预约  02网上办证  3网上证明
	if(onlinetype == "01") { //网上预约
		var submitBtns = document.getElementsByClassName("submitbtn");
		for(var i = 0; i < submitBtns.length; i++) {
			//			submitBtns[i].innerHTML = "我要预约";
		}
		var details = document.getElementsByClassName("detailTable");
		for(var i = 0; i < details.length; i++) {
			details[i].style.display = "none";
		}

		var onlinedeclares = document.getElementsByClassName("onlinedeclare");
		for(var i = 0; i < onlinedeclares.length; i++) {
			onlinedeclares[i].style.display = "none";
		}
		var onlineorders = document.getElementsByClassName("onlineorder");
		for(var i = 0; i < onlineorders.length; i++) {
			onlineorders[i].style.display = "block";
		}
	} else { //网上办证
		var submitBtns = document.getElementsByClassName("submitbtn");
		for(var i = 0; i < submitBtns.length; i++) {
			submitBtns[i].innerHTML = "在线办理";

			foruser = dataArray[i].foruser;
			//			if(userInfo.appConEntName == "" || typeof(userInfo.appConEntName) == "undefined") { //个人
			//				if(foruser == "2" || foruser == "3" || foruser == "6") { //法人用户
			//					submitBtns[i].style.backgroundColor = "#8E8E93";
			//					submitBtns[i].accesskey = "fr";
			//				}
			//			} else { //法人
			//				if(foruser == "1" || foruser == "3" || foruser == "5") { //个人用户
			//					submitBtns[i].style.backgroundColor = "#8E8E93";
			//					submitBtns[i].accesskey = "gr";
			//				}
			//			}
		}
		var details = document.getElementsByClassName("detailTable");
		for(var i = 0; i < details.length; i++) {
			details[i].style.display = "block";
		}
		var onlinedeclares = document.getElementsByClassName("onlinedeclare");
		for(var i = 0; i < onlinedeclares.length; i++) {
			onlinedeclares[i].style.display = "block";
		}
		var onlineorders = document.getElementsByClassName("onlineorder");
		for(var i = 0; i < onlineorders.length; i++) {
			onlineorders[i].style.display = "none";
		}
	}
}